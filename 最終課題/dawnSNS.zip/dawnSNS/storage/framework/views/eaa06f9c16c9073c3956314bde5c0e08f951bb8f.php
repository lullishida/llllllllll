<?php $__env->startSection('content'); ?>

<div id="clear">
<p>〇〇さん、</p>
<p>ようこそ！DAWNSNSへ！</p>
<p>ユーザー登録が完了しました。</p>
<p>さっそく、ログインをしてみましょう。</p>

<p class="btn"><a href="/login">ログイン画面へ</a></p>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('logout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>