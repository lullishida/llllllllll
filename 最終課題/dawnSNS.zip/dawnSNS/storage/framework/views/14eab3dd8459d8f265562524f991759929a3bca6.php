<?php $__env->startSection('content'); ?>
<h2>機能を実装していきましょう。</h2>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>